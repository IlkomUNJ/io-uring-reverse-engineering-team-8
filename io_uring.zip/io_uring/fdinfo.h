// SPDX-License-Identifier: GPL-2.0

void io_uring_show_fdinfo(struct seq_file *m, struct file *f);
